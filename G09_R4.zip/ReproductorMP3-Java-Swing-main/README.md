# ReproductorMP3-Java-Swing

<p align="center">
  <img src="https://i.postimg.cc/WzJdXWrb/logo-java-png.png" width="200" alt="Logo" />
</p>

<img src="Screenshot/pantalla.PNG"/>


## Reproductor de MP3 en Java 8 Proyecto de Clase.

Funciones:

* Arrastrar para agregar canciones
* Subir/Bajar Volumen
* Adelantar/Retrasar Sonido
* Guardar Listas de Reproduccción.
